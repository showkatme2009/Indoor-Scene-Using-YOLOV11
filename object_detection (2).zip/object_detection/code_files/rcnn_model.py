import torchvision
from PIL import Image, ImageDraw, ImageFont
import torchvision.transforms as T
import torch

# Load pre-trained Faster R-CNN
rcnn_model = torchvision.models.detection.fasterrcnn_resnet50_fpn(weights="DEFAULT")
rcnn_model.eval()

# Load image and convert to RGB
image = Image.open('../image1.jpeg').convert('RGB')

# Transform to tensor
transform = T.Compose([T.ToTensor()])
image_tensor = transform(image).unsqueeze(0)  # Add batch dimension

# Run inference
with torch.no_grad():
    outputs = rcnn_model(image_tensor)

# COCO classes
coco_classes = [
    '__background__', 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus',
    'train', 'truck', 'boat', 'traffic light', 'fire hydrant', 'N/A', 'stop sign',
    'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
    'elephant', 'bear', 'zebra', 'giraffe', 'N/A', 'backpack', 'umbrella', 'N/A', 'N/A',
    'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball',
    'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket',
    'bottle', 'N/A', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl',
    'banana', 'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza',
    'donut', 'cake', 'chair', 'couch', 'potted plant', 'bed', 'N/A', 'dining table',
    'N/A', 'N/A', 'toilet', 'N/A', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
    'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'N/A', 'book',
    'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush'
]

# Draw bounding boxes on image
draw = ImageDraw.Draw(image)

# Try loading a basic font (optional, will fallback to default if not found)
try:
    font = ImageFont.truetype("arial.ttf", 15)
except IOError:
    font = ImageFont.load_default()

for box, label, score in zip(outputs[0]['boxes'], outputs[0]['labels'], outputs[0]['scores']):
    if score > 0.5:  # Only process boxes above confidence threshold
        if label < len(coco_classes):
            class_name = coco_classes[label]
        else:
            class_name = f"Unknown (Label {label})"

        # Extract box coordinates
        x1, y1, x2, y2 = box.tolist()

        # Draw rectangle
        draw.rectangle([x1, y1, x2, y2], outline="red", width=2)

        # Draw label
        text = f"{class_name} {score:.2f}"
        text_size = draw.textbbox((x1, y1), text, font=font)  # Calculate text size
        draw.rectangle([text_size[0], text_size[1], text_size[2], text_size[3]], fill="red")
        draw.text((x1, y1), text, fill="white", font=font)

# Save annotated image
image.save("output_with_boxes_rcnn.png")
print("Saved output image with boxes as 'output_with_boxes_rcnn.png'")
