from ultralytics import YOLO
from PIL import Image, ImageDraw, ImageFont

# Load YOLOv8 segmentation model
yolo_model = YOLO('../yolov8n-seg.pt')

coco_classes = [
    'person', 'bicycle', 'car', 'motorcycle', 'airplane',
    'bus', 'train', 'truck', 'boat', 'traffic light',
    'fire hydrant', 'stop sign', 'parking meter', 'bench',
    'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
    'elephant', 'bear', 'zebra', 'giraffe', 'backpack',
    'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
    'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat',
    'baseball glove', 'skateboard', 'surfboard', 'tennis racket',
    'bottle', 'wine glass', 'cup', 'fork', 'knife',
    'spoon', 'bowl', 'banana', 'apple', 'sandwich',
    'orange', 'broccoli', 'carrot', 'hot dog', 'pizza',
    'donut', 'cake', 'chair', 'couch', 'potted plant',
    'bed', 'dining table', 'toilet', 'tv', 'laptop',
    'mouse', 'remote', 'keyboard', 'cell phone', 'microwave',
    'oven', 'toaster', 'sink', 'refrigerator', 'book',
    'clock', 'vase', 'scissors', 'teddy bear', 'hair drier',
    'toothbrush'
]

def draw_boxes_and_masks(image_path, results, output_path='output_with_boxes.png'):
    image = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(image)

    # Font for text labels
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except IOError:
        font = ImageFont.load_default()

    # Process each detection
    for result in results:
        for i, box in enumerate(result.boxes):
            class_id = int(box.cls[0].item())
            confidence = box.conf[0].item()
            class_name = coco_classes[class_id]

            # Bounding box coordinates
            x1, y1, x2, y2 = box.xyxy[0].tolist()

            # Draw bounding box
            draw.rectangle([x1, y1, x2, y2], outline="red", width=3)

            # Draw class label and confidence
            label = f"{class_name} {confidence:.2f}"
            text_size = draw.textbbox((x1, y1), label, font=font)
            draw.rectangle([text_size[0], text_size[1], text_size[2], text_size[3]], fill="red")
            draw.text((x1, y1), label, fill="white", font=font)

            # Draw segmentation mask (if available)
            if result.masks is not None and i < len(result.masks.xy):
                mask_polygons = result.masks.xy[i]  # List of polygons for this object (can be multiple)

                for polygon in mask_polygons:
                    # Ensure polygon is a proper list of (x, y) points
                    if len(polygon.shape) == 2 and polygon.shape[1] == 2:
                        draw.line([tuple(point) for point in polygon] + [tuple(polygon[0])], fill="lime", width=2)
                    else:
                        print(f"Skipping invalid polygon for class {class_name}")

    # Save image with annotations
    image.save(output_path)
    print(f"Saved image with boxes and masks to {output_path}")

def detect_objects_and_segments(image_path):
    results = yolo_model(image_path)

    detected_objects = []
    segmentation_masks = []

    for result in results:
        for i, box in enumerate(result.boxes):
            class_id = int(box.cls[0].item())
            confidence = box.conf[0].item()

            detected_objects.append({
                'class_id': class_id,
                'confidence': confidence
            })

            if result.masks is not None:
                mask = result.masks.xy[i]
                segmentation_masks.append({
                    'class_id': class_id,
                    'mask': mask
                })

    return detected_objects, segmentation_masks, results


def infer_context(detected_objects):
    object_counts = {}

    for obj in detected_objects:
        class_name = coco_classes[obj['class_id']]
        if class_name in object_counts:
            object_counts[class_name] += 1
        else:
            object_counts[class_name] = 1

    if 'bed' in object_counts and 'tv' in object_counts:
        return 'Likely a Bedroom'
    elif 'dining table' in object_counts and 'chair' in object_counts:
        return 'Likely a Dining Room'
    elif 'couch' in object_counts and 'tv' in object_counts:
        return 'Likely a Living Room'
    elif 'toilet' in object_counts and 'sink' in object_counts:
        return 'Likely a Bathroom'
    elif 'car' in object_counts or 'truck' in object_counts:
        return 'Likely a Garage or Outdoor Scene'

    return 'Unknown Scene'


if __name__ == '__main__':
    image_path = '../image1.jpeg'  # Replace with your actual image path

    detected_objects, segmentation_masks, results = detect_objects_and_segments(image_path)

    print("Detected Objects:")
    for obj in detected_objects:
        class_name = coco_classes[obj['class_id']]
        print(f"Class: {class_name}, Confidence: {obj['confidence']:.2f}")

    context = infer_context(detected_objects)
    print(f"\nContextual Analysis: {context}")

    if segmentation_masks:
        print("\nSegmentation Masks (if using segmentation model):")
        for mask in segmentation_masks:
            class_name = coco_classes[mask['class_id']]
            print(f"Class: {class_name}, Mask Points: {len(mask['mask'])}")

    # Draw boxes and save image with boxes/masks
    draw_boxes_and_masks(image_path, results, 'output_with_boxes_yolo.png')
